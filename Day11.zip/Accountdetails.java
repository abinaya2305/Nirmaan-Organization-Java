package day12;

public class Accountdetails {
	
	private int id;
	private String Name;
	private int accountNo;
	private double Balance = 100000;
	private int pin = 1234;
	
	
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccount(int account) {
		this.accountNo = account;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public double getBalance() {
		return Balance;
	}
	public void setBalance(double balance,int pin) {
		if(this.pin==pin) {
			this.Balance = balance;
		}else {
			System.out.println("invalidPin");
		}
	}
	
	public Accountdetails (int id, String Name, int Account, double balance,int pin) {
		this.id = id;
		this.Name = Name;
		this.accountNo = Account;
		if(this.pin==pin) {
			this.Balance = balance;
		}else {
			System.out.println("invalidPin");
		}
		
	}
	public Accountdetails() {
		
	}
	@Override
	public String toString() {
		return "Accountdetails [id=" + id + ", Name=" + Name + ", accountNo=" + accountNo + ", Balance=" + Balance
				+ "]";
	}
	
	
	
	
	
	

}
