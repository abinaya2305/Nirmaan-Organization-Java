package day12;

import java.util.Scanner;

public class UI {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Accountdetails acc = new Accountdetails();
		boolean iswork = true;
		
		while (iswork) {
			System.out.print("Enter 1 for add Create Account: ");
			System.out.println("Enter 2 for Withdraw: ");
			System.out.println("Enter 3 for show Accountdetails: ");
			System.out.println("Enter 4 for Deposit: ");
			System.out.println("Enter 5 for Exit: ");
			int key = sc.nextInt();
			
			if(key==1) {
				System.out.println("Enter the AccountNo: ");
				int accountno = sc.nextInt();
				sc.nextLine();
				System.out.println("Enter the ID: ");
				int id = sc.nextInt();
				System.out.println("Enter the Name: ");
				String name = sc.next();
				
				acc = new Accountdetails();	    
				} 
			else if (key==2) {
				sc.nextLine();
				System.out.println("Enter the Pin: ");
				int pin = sc.nextInt();
				System.out.println("Enter the Amount: ");
				double amount = sc.nextInt();
				double existbalance = acc.getBalance();
				double total = existbalance - amount;
				System.out.println("Remaining amount: "+total );
				acc.setBalance(total,pin);
					
				}
			else if (key==3) {
				System.out.println(acc);
			}
			else if(key==4){
				System.out.println("Enter the Pin: ");
				int pin = sc.nextInt();
				System.out.println("Enter the amount: ");
				double amount = sc.nextDouble();
				double existbalance = acc.getBalance();
				double total = existbalance + amount;
				System.out.println("Remaining amount: "+ total);
			}
			else if(key==5){
				break;
			}
		}
		sc.close();
		
	}

}
