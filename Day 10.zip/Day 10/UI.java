package day10;

import java.util.Scanner;

public class UI {
	public static void main(String[] args) {
		Calculator cal = new Calculator();
		
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the 1st number : ");
		int num1 = sc.nextInt();
		System.out.print("Enter the 2nd number : ");
		int num2 = sc.nextInt();
		cal.add(num1,num2);
		cal.sub(num1,num2);
		cal.mul(num1,num2);
		cal.div(num1,num2);
		cal.mod(num1,num2);
		
		sc.close();
	}

}
